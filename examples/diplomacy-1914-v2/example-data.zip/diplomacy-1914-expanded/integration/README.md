# Optional native-core source-span retrieval patch

This small patch is separate from the source corpus. It modifies the existing Apache-2.0 native core, and it must retain that license and applicable upstream notices. It is not proprietary code and does not relicense the historical texts.

- File: `source-span-recall.patch`
- SHA-256: `5dbf6a9c000b7a381601063115c9b08d4b509d239b7edd9d2c4b0067f3856611`
- Intended public-core base reported by the builder: `0d47eafd93f2b4a5e4a926d3c761410b1c319cd6`
- The builder also reports compatibility with `9779f7367872789227601e28d5f39658284f8b34`, whose intervening changes are in documents/harness
- Candidate source pin used for the native corpus examples: `03fe8e6`

The change adds an independent literal lexical match against already cited, hash-validated source spans, retaining the existing bounded graph closure. It does not perform semantic extraction, embedding search or truth validation. The patch includes four regression tests. The core worker reports independent validation of 135 tests, strict Clippy and eight collection-harness tests; these are code/behavior tests, not historical accuracy results.

Check the patch against the selected base with the destination repository's normal review and test workflow. Do not apply it to an unrelated checkout or replace the existing core contracts. Use the repository's supported isolated Rust workspace for building `knowledge_capture`. The corpus receipt identifies the tested binary hash; rebuilding on a different toolchain can change binary bytes while preserving behavior.

This example supplies the patch for the pinned core dependency. It does not represent the patch as merged upstream or the website integration as tested.
