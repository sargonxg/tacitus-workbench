# Could a diplomat see escalation coming in July 1914?

A reproducible historical evidence collection for TACITUS, with original source bytes, exact text hashes, dated source locators and explicitly authored, unreviewed claim examples.

## What is actually here

- 162 distinct official FRUS dispatch/document records (d24–d185), from one 1928 documentary volume, covering the crisis and the first weeks of war
- Four separately identified sections of Lichnowsky's retrospective memoir, composed in August 1916 according to that edition
- 209,963 bytes of normalized source text
- 1,069 structural text blocks, including 598 paragraph blocks; these are **not** 1,069 inferred claims
- A bounded native Capture example: 28 source records, 39 assistant-authored claim proposals, 21 typed actor/institution/event nodes and 12 explicit claim links
- 160 literal phrase occurrences with exact UTF-8 offsets, not a learned rhetoric classifier

These are two source works, 166 selected records, and a much smaller annotated graph. No synthetic repetition increases the counts. No automatic extraction quality, semantic retrieval improvement, compression ratio, historian agreement or 100–1,000-book ingestion performance is claimed.

Read [RIGHTS.md](RIGHTS.md) before reuse. The FRUS master files are explicitly public domain; the specific memoir ebook is declared public domain in the USA and carries separate Gutenberg terms. The repository policy does not narrow rights in those source texts. This example is publicly accessible; new eligible original material has no open-source grant unless separately identified. See the repository rights policy.

## A compelling evidence journey

1. **July 27: conflicting outlooks.** Gerard says he has reason to believe general war can be avoided (d27). Penfield calls war certain but probably localized, with the Russian attitude unknown (d32). Mallett's July 13 warning arrives only on July 27 (d28). A source's writing date is not the date Washington could read it.
2. **July 28–30: warnings intensify.** Wilson distinguishes mobilization activity from an unpublished decree (d30), then says war is inevitable (d38). Gerard moves from July 27 optimism to July 30 certainty of general war (d41). Preserve these as dated assessments rather than flattening them into a timeless contradiction.
3. **What diplomatic language commits to.** The Secretary's July 28 question about “good offices” (d34) differs from Page's informal invitation to Grey (d36) and the later presidential offer (d92). Courtesy, willingness and acceptance are separate. Austria's declaration includes an explicit reciprocity condition concerning conventions (d35).
4. **What was known versus rumored.** Bundy preserves “Official report not verified” (d42); Page calls military-operation rumors unconfirmed (d95). Page's subsequent receipt of an official war note (d96) does not confirm the rumors.
5. **Turn hindsight on explicitly.** Lichnowsky later admits underestimation, claims he warned against localization, and describes a neutrality misunderstanding involving scope and speech act. These passages cannot be used in a July 1914 snapshot.
6. **Inspect a discrepancy without silently repairing it.** Lichnowsky says the German declaration against Russia was on July 31; Wilson's August 1 telegram reports its presentation around 6 p.m. (d58). The proposed conflict calls for review, including whether issuing and presenting refer to the same event. It does not prove deceit or settle war responsibility.

Useful public starting points: [Gerard, July 27](https://history.state.gov/historicaldocuments/frus1914Supp/d27), [Gerard, July 30](https://history.state.gov/historicaldocuments/frus1914Supp/d41), [Mallett's delayed report](https://history.state.gov/historicaldocuments/frus1914Supp/d28), [mobilization qualification](https://history.state.gov/historicaldocuments/frus1914Supp/d30), [the undated Gibraltar telegram](https://history.state.gov/historicaldocuments/frus1914Supp/d39), [German declaration report](https://history.state.gov/historicaldocuments/frus1914Supp/d58), [memoir edition](https://www.gutenberg.org/ebooks/39457).

## Files and reproducibility

- `integration/`: optional Apache-2.0 core patch and preserved license, distinct from corpus rights
- `DEMO_QUERIES.json`: eight curated demonstration questions, with relevant claims and required caveats; not a held-out benchmark
- `upstream/`: immutable downloaded master bytes, source license and download hashes
- `corpus-manifest.json`: provenance, rights, transformations and per-document hashes
- `corpus-index.json`: the same catalog plus complete normalized text, publisher-marked people, editorial notes and exact structural block spans
- `texts/`: normalized UTF-8 records actually ingested by the example
- `annotations/capture.unfingerprinted.json`: existing native Capture contract, pending native Rust fingerprint calculation
- `annotations/capture.json`: supplied native fingerprinted input
- `annotations/historical-view.json`: research/display metadata separating creation, receipt, event and memoir composition dates
- `annotations/phrase-occurrences.json`: literal substring matches with byte spans
- `scripts/build_corpus.py`: deterministic structural extraction, not semantic extraction
- `scripts/build_annotations.py`: reproducible explicit annotations, not model-generated extraction
- `scripts/verify_corpus.py`: offline hash/span/date-exclusion checks
- `scripts/historical_snapshot.py`: calendar-based reconstruction with explicit unknown-date withholding

From this directory:

    python3 scripts/build_corpus.py
    python3 scripts/build_annotations.py
    python3 scripts/verify_corpus.py
    python3 scripts/historical_snapshot.py --cutoff 1914-07-27 --basis source-created
    python3 scripts/historical_snapshot.py --cutoff 1914-07-30 --basis recipient-received

Regeneration writes the unfingerprinted proposal, not a validated native capture. Native claim fingerprints must come from `PolicyAssertion::fingerprint` in the Rust implementation. Use the existing `knowledge_capture pack`, `inspect`, and `reuse` tools after native fingerprinting. Never hand-wave JSON canonicalization or set human-review flags.

Upstream retrieval URLs, redirects, times and SHA-256 digests are in `upstream/downloads.json`. FRUS is pinned to a specific Git commit. Gutenberg's current endpoint is not immutable: a later fetch may have a different header/license or text. A checksum change is a reason to inspect and version the new source, not to silently overwrite the pinned file or reuse old spans.

## Time and hindsight boundaries

There are several separate clocks:

- the historical document's date as printed/encoded
- the recipient's receipt date/time, if printed
- the event time claimed in its text
- the edition's publication date (FRUS: 1928)
- memoir composition (August 1916, according to the edition)
- modern retrieval, annotation and capsule availability (2026)

`document_date` is Gregorian for the FRUS dated records. It does not assert receipt by any particular diplomat. For a “source-created” reconstruction, only documents with a known creation calendar date on or before the cutoff are admitted. For a “recipient-received” reconstruction, only explicitly printed receipt calendar dates are admitted; receipt times without a date are withheld rather than guessed. These are different partial views. An undated telegram can be received on a known date; a Beijing dispatch dated July 31 can have a Washington receipt dated July 30. Preserve the source clocks.

The native `known_as_of` means availability in the modern corpus, **not** historical knowledge in 1914. Native `published_at`, world-validity intervals, event instants and observation instants remain null when not established. A calendar date is not turned into a fictional midnight UTC. The full native capsule should refuse a `known_as_of` request for 1914 because its graph did not yet exist. Historical playback is an expressly labeled source selection over the separate calendar metadata, not time travel through the modern graph.

Default historical views exclude every retrospective memoir claim. A comparative synthesis is included only if all of its evidence sources are eligible. The 1928 editorial footnotes are kept out of dispatch text and separately labeled. Inline brackets and amendments remain as printed; this is an edited-text reconstruction, not an unaltered telegram facsimile. Do not assume a bracketed correction was known to the historical recipient.

## Source and inference limits

FRUS is an official, edited U.S. documentary selection, not all of Europe's diplomatic traffic. These dispatches contain guesses, rumors, self-description, uncertain spellings and editorial interventions. Lichnowsky's memoir is retrospective and interested testimony. Neither a source's government provenance nor its confident wording makes every assertion true.

The graph uses the project's existing SourceRecord, Span, PolicyAssertion and Graph contracts. The corpus catalog and date sidecar are indexing/display metadata, not an alternative ontology. Links have explicit rationale. Contradiction is proposed sparingly; a change of forecast over time is represented by a source-backed comparison with dependencies.

The source language is English. Some documents are historical translations; the memoir embeds French words and an edition-provided English gloss. This demonstrates preserving linguistic provenance and scope, not multilingual model performance. An actual evaluation needs separately reviewed held-out tasks, matched retrieval scope, source-level leakage controls, and relevance versus purpose-specific usefulness judgments.

## Native validation performed

The supplied native package was built and inspected by the Rust implementation, not a parallel JSON packer:

- Package: `july-1914.native-v2.zip`
- SHA-256: `c7268bef3b19ff9b93458a64e476dd52df1c76f074e77fe149d2983268a66e5f`
- Native candidate source pin used by the builder: `03fe8e6`; the reviewed source patch and pinned public base reproduce this candidate; semantic annotations remain unreviewed
- Four repeat query outputs reproduce exactly: mediation, mobilization, peace and retrospective comparison
- Every selected assertion/citation was checked against the supplied source bytes
- Full native repack reproduces the same archive bytes
- Strict unknown-time, pre-ingestion, actual 1914 checkpoint, revoked-source and evidence-tampering cases refuse with nonzero status and empty stdout
- Thirteen offline corpus integrity/date-leakage tests pass

The native receipt is `validation/native/acceptance.json`. It reports structural checks, not historical truth or extraction accuracy. The graph's annotations remain unreviewed.

For portable revalidation with the existing built CLI:

    python3 validation/verify_native.py --binary /path/to/knowledge_capture

To regenerate fingerprints, use `scripts/fingerprint_capture.rs` as an example in the existing supported isolated Rust workspace (it depends on the project's `tacitus-analysis` and `tacitus-capsules` crates). It deserializes the existing Capture and calls `PolicyAssertion::fingerprint`; it does not invent canonical JSON or change assertions. Copy it into that workspace's `crates/tacitus-analysis/examples/fingerprint_capture_local.rs`, then run the example with `annotations/capture.unfingerprinted.json` on stdin and save stdout as `annotations/capture.json`. Build using that workspace's documented locked toolchain. BTreeSet serialization sorts graph node claim lists; this is an order normalization, not an added claim.
