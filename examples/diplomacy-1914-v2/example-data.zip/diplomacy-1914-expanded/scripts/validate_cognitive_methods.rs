// Original integration helper; licensing follows RIGHTS.md.
// Uses the separately Apache-2.0 TACITUS native contracts; retain dependency notices.
use std::{collections::BTreeMap, fs};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() != 3 { return Err("usage: validate_cognitive_methods CAPTURE.json METHODS.json".into()); }
    let capture: tacitus_analysis::knowledge_capture::Capture =
        tacitus_capsules::strict_json::from_slice(&fs::read(&args[1])?)?;
    let methods: Vec<tacitus_core::policy::CognitiveMethod> =
        tacitus_capsules::strict_json::from_slice(&fs::read(&args[2])?)?;
    if methods.is_empty() || methods.len() > 256 { return Err("bounded nonempty method list required".into()); }
    let sources: BTreeMap<_,_> = capture.documents.into_iter().map(|s| (s.key(),s)).collect();
    for source in sources.values() { source.validate()?; }
    let mut fingerprints = BTreeMap::new();
    for method in &methods {
        method.validate(&sources)?;
        if fingerprints.insert(method.id.clone(), method.fingerprint()).is_some() { return Err("duplicate method id".into()); }
    }
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "format":"tacitus-native-method-validation/1", "methods":methods.len(),
        "fingerprints":fingerprints, "scope":"Native typed provenance validation only; methods remain unreviewed and are not ingested by knowledge_capture reuse."
    }))?);
    Ok(())
}
