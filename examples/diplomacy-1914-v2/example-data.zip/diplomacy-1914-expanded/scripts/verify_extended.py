#!/usr/bin/env python3
"""Exact-byte and reference tests; not a historical accuracy score."""
from pathlib import Path
import copy,hashlib,json,sys,unittest
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'))
from historical_snapshot import select
C=json.loads((R/'corpus-index.json').read_text());D={x['id']:x for x in C['documents']}
P=json.loads((R/'annotations/expanded/capture.json').read_text());A={x['id']:x for x in P['assertions']};S={x['id']+'@1':x for x in P['documents']}
K=json.loads((R/'EXPANDED_CASEBOOK.json').read_text());M=json.loads((R/'annotations/expanded/cognitive-methods.json').read_text())
class ExtendedIntegrity(unittest.TestCase):
 def test_native_limits_and_actual_counts(self):
  self.assertEqual(len(S),31);self.assertEqual(len(A),46);self.assertEqual(len(P['graph']['nodes']),22);self.assertEqual(len(P['graph']['links']),36)
  self.assertLessEqual(len(S),32);self.assertLessEqual(len(A),256)
 def test_exact_sources(self):
  for s in S.values():
   d=D[s['id']];self.assertEqual(s['text'],d['text']);self.assertEqual(s['text_hash'],d['text_sha256']);self.assertEqual(s['original_hash'],d['text_sha256']);self.assertEqual(s['workspace'],P['manifest']['scope']);self.assertEqual(d['rights_id'],'frus-public-domain')
 def test_all_span_bytes_and_metadata(self):
  for a in list(A.values())+M:
   for e in a['evidence']:
    s=S[e['source']];b=s['text'].encode();self.assertEqual(e['text_hash'],hashlib.sha256(b).hexdigest());self.assertTrue(b[e['start']:e['end']].decode());self.assertTrue(e['locator'].startswith('https://history.state.gov/'));self.assertEqual(e['original_language'],'en');self.assertIsNone(e['translation'])
 def test_casebook_references_resolve(self):
  self.assertEqual(len(K['cases']),10)
  for case in K['cases']:
   self.assertTrue(case['source_claim_ids'])
   for key in case['source_claim_ids']:self.assertIn(key,A)
   if case['comparison_claim_id']:
    key=case['comparison_claim_id'];self.assertIn(key,A);self.assertEqual(A[key]['epistemic_type'],'inference')
    self.assertEqual(set(case['source_claim_ids']),{l['to']for l in P['graph']['links']if l['from']==key})
 def test_all_graph_references_and_fingerprints(self):
  self.assertEqual(set(P['graph']['claim_fingerprints']),set(A))
  for node in P['graph']['nodes'].values():self.assertTrue(set(node['claims'])<=set(A));self.assertIsNone(node['event_time'])
  for edge in P['graph']['links']:self.assertIn(edge['from'],A);self.assertIn(edge['to'],A);self.assertEqual(edge['kind'],'depends_on')
 def test_fingerprinting_preserves_proposal_content(self):
  raw=json.loads((R/'annotations/expanded/capture.unfingerprinted.json').read_text());native=copy.deepcopy(P)
  for obj in (raw,native):
   obj['graph'].pop('claim_fingerprints')
   for node in obj['graph']['nodes'].values():node['claims']=sorted(node['claims'])
  self.assertEqual(raw,native)
 def test_native_method_proposals_are_scoped_and_unreviewed(self):
  self.assertEqual(len(M),10);self.assertEqual(len({m['id']for m in M}),10)
  receipt=json.loads((R/'validation/cognitive-methods-native.json').read_text());self.assertEqual(set(receipt['fingerprints']),{m['id']for m in M})
  for m in M:
   self.assertEqual(m['ontology_version'],'tacitus-policy/1');self.assertTrue(m['prerequisites']);self.assertTrue(m['failure_conditions']);self.assertIn('Unreviewed',m['description']);self.assertEqual(m['created_at'],m['available_at']);self.assertEqual(m['workspace'],P['manifest']['scope'])
 def test_method_proposals_are_not_claimed_as_ingested(self):
  self.assertNotIn('methods',P);self.assertEqual(P['graph']['knowledge'],{});self.assertTrue(all(v is None for v in P['observed_at'].values()))
  self.assertNotIn('reviews',P)
 def test_important_qualifications_not_lost(self):
  text=json.dumps(A['bernstorff-reciprocal-mediation-belief']);self.assertIn('extent of any prior authority is not established',text)
  text=json.dumps(A['hospital-immunity-with-requisition-exception']);self.assertIn('urgent military necessity',text);self.assertIn('Compensation',text)
  text=json.dumps(A['relief-assurance-conditional-duration']);self.assertIn('unspecified reasonable period',text)
 def test_authorization_comparison_cannot_leak_future_record(self):
  result=select(C,P,'1914-10-18','source-created');self.assertNotIn('relief-permission-sequence',result['claim_ids']);self.assertNotIn('relief-us-authorization',result['claim_ids']);self.assertIn('relief-german-approval-reported',result['claim_ids'])
 def test_composite_case_withheld_on_affected_clock(self):
  result=select(C,P,'1914-08-04','source-created');self.assertNotIn('whitlock-provisional-custody',result['claim_ids']);self.assertNotIn('protection-authority-scope',result['claim_ids'])
 def test_current_rights_scope_is_not_baseline_count(self):
  rights=(R/'RIGHTS.md').read_text();self.assertIn('618 distinct publisher document',rights);self.assertIn('18 complete chapters',rights);self.assertIn('Public domain in the USA',rights)
if __name__=='__main__':unittest.main(verbosity=2)
