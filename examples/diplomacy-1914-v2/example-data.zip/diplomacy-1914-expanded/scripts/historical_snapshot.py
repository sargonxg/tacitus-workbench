#!/usr/bin/env python3
"""Explicit calendar-selection metadata, never a substitute for native corpus availability."""
from pathlib import Path
import argparse,datetime,json
ROOT=Path(__file__).resolve().parents[1]
def select(corpus,capture,cutoff,basis):
 datetime.date.fromisoformat(cutoff)
 if basis not in ('source-created','recipient-received'):raise ValueError('unknown historical selection basis')
 eligible=[]; withheld={}
 field='document_date' if basis=='source-created' else 'recipient_received_calendar_date'
 for d in corpus['documents']:
  if d['source_kind']=='retrospective_memoir_section':
   withheld[d['id']]='retrospective composition in 1916; excluded from 1914 reconstruction';continue
  ambiguous='source_created_ambiguous' if basis=='source-created' else 'recipient_received_ambiguous'
  if d.get('date_quality',{}).get(ambiguous,False):withheld[d['id']]='known ambiguity for selected date basis; pending review';continue
  day=d.get(field)
  if day is None:withheld[d['id']]='unknown calendar date for selected basis';continue
  if day>cutoff:withheld[d['id']]='later than cutoff';continue
  eligible.append(d['id'])
 allowed=set(eligible)
 claims=[a['id'] for a in capture['assertions'] if all(e['source'].rsplit('@',1)[0] in allowed for e in a['evidence'])]
 chosen=set(claims)
 links=[e for e in capture['graph']['links'] if e['from'] in chosen and e['to'] in chosen]
 return {'format':'tacitus-historical-selection/1','cutoff_calendar_date':cutoff,'basis':basis,'warning':'Partial retrospective reconstruction from selected historical records. A source creation date is not proof that any particular diplomat had received or read it. Native known_as_of remains modern corpus availability. No memoir or undated evidence is assigned a guessed historical availability.','source_ids':eligible,'claim_ids':claims,'relationships':links,'withheld_sources':withheld}
def main():
 p=argparse.ArgumentParser();p.add_argument('--cutoff',required=True);p.add_argument('--basis',choices=['source-created','recipient-received'],required=True);p.add_argument('--output');p.add_argument('--annotation-set',choices=['baseline','expanded','both'],default='both');a=p.parse_args()
 c=json.loads((ROOT/'corpus-index.json').read_text());caps=[]
 if a.annotation_set in ('baseline','both'):caps.append(json.loads((ROOT/'annotations/capture.unfingerprinted.json').read_text()))
 if a.annotation_set in ('expanded','both'):caps.append(json.loads((ROOT/'annotations/expanded/capture.unfingerprinted.json').read_text()))
 cap={'assertions':[x for item in caps for x in item['assertions']],'graph':{'links':[x for item in caps for x in item['graph']['links']]}}
 result=select(c,cap,a.cutoff,a.basis);content=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
 if a.output:Path(a.output).write_text(content)
 else:print(content,end='')
if __name__=='__main__':main()
