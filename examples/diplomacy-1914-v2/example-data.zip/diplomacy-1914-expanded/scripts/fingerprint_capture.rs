// SPDX-License-Identifier: Apache-2.0
// Native TACITUS helper; preserve integration/LICENSE-APACHE-2.0.txt and NOTICE-TACITUS.md.
use std::io::{Read, Write};
fn main() {
    let mut raw = Vec::new();
    std::io::stdin()
        .take(2 * 1024 * 1024 + 1)
        .read_to_end(&mut raw)
        .unwrap();
    let mut c: tacitus_analysis::knowledge_capture::Capture =
        tacitus_capsules::strict_json::from_slice(&raw).unwrap();
    c.graph.claim_fingerprints = c
        .assertions
        .iter()
        .map(|a| (a.id.clone(), a.fingerprint()))
        .collect();
    std::io::stdout()
        .write_all(&serde_json::to_vec_pretty(&c).unwrap())
        .unwrap();
}
