#!/usr/bin/env python3
"""Reproduce native capsule behavior. This is not a semantic-quality benchmark."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', required=True, type=Path)
    args = parser.parse_args()
    binary = args.binary.resolve()
    if not binary.is_file():
        parser.error('native binary does not exist')
    capture_path = ROOT / 'annotations/expanded/capture.json'
    archive = ROOT / 'expanded-cases.native-v2.zip'
    capture = json.loads(capture_path.read_text())
    documents = {f"{d['id']}@{d['version']}": d for d in capture['documents']}
    claims = {a['id']: a for a in capture['assertions']}
    checks = []

    def run(arguments, request=None):
        return subprocess.run(
            [str(binary), *map(str, arguments)],
            input=None if request is None else json.dumps(request).encode(),
            capture_output=True, timeout=30,
        )

    requests = sorted((ROOT / 'validation/expanded-native').glob('*.request.json'))
    assert len(requests) == 6, 'six frozen example requests required'
    for path in requests:
        request = json.loads(path.read_text())
        expected = path.with_name(path.name.replace('.request.', '.context.')).read_bytes()
        actual = run(['reuse', archive], request)
        assert actual.returncode == 0 and actual.stdout == expected, path.name
        assert len(expected) <= request['max_bytes']
        context = json.loads(expected)['context']
        assert context['claims'], 'the example must contain evidence'
        for key, value in context['claims'].items():
            assert value['assertion'] == claims[key]
            for citation in value['citations']:
                span = citation['span']
                source = documents[span['source']]
                raw = source['text'].encode()
                assert raw[span['start']:span['end']].decode() == citation['text']
                assert hashlib.sha256(raw).hexdigest() == span['text_hash']
        checks.append({'case': path.stem, 'exact_reproduction': True,
                       'claims': len(context['claims']), 'bytes': len(expected)})

    request = json.loads((ROOT / 'validation/expanded-native/relief.request.json').read_text())
    refusal_cases = [
        ('strict', {'time_mode': 'require_declared_interval'}),
        ('pre_ingestion', {'known_as_of': capture['manifest']['created_at'] - 1}),
        ('historical_1914', {'known_as_of': int(datetime.datetime(1914, 7, 27, tzinfo=datetime.timezone.utc).timestamp())}),
        ('revoked', {'revoked_sources': [next(iter(documents))]}),
    ]
    for name, change in refusal_cases:
        result = run(['reuse', archive], request | change)
        assert result.returncode != 0 and not result.stdout, name
        checks.append({'case': name, 'rejected_empty_stdout': True})

    with tempfile.TemporaryDirectory() as directory:
        rebuilt = Path(directory) / 'rebuilt.zip'
        result = run(['pack', capture_path, rebuilt])
        assert result.returncode == 0 and rebuilt.read_bytes() == archive.read_bytes()
        checks.append({'case': 'deterministic_repack', 'exact_bytes': True})
        tampered = Path(directory) / 'tampered.zip'
        changed = False
        with zipfile.ZipFile(rebuilt) as source, zipfile.ZipFile(tampered, 'w') as target:
            for name in source.namelist():
                data = source.read(name)
                if name.startswith('evidence/') and not changed:
                    data += b'!'
                    changed = True
                target.writestr(name, data)
        assert changed
        result = run(['inspect', tampered])
        assert result.returncode != 0 and not result.stdout
        checks.append({'case': 'evidence_tamper', 'rejected_empty_stdout': True})

    print(json.dumps({
        'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
        'checks': checks,
        'scope': 'Structural local validation only; annotations unreviewed; modern ingestion checkpoint is not historical knowledge.',
    }, indent=2))


if __name__ == '__main__':
    main()
