"""Local content-addressed lexical source index; no native capsule or semantic claims."""
import argparse,datetime,hashlib,json,pathlib,shutil
from lexical_reference import tokens
MAX_DOCS=1000; MAX_SHARD=25; MAX_INPUT=32*1024*1024

def enc(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def pairs(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('duplicate JSON key')
  d[k]=v
 return d

def read(p):
 b=pathlib.Path(p).read_bytes()
 if len(b)>MAX_INPUT:raise ValueError('input too large')
 return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def digest_ok(v):return isinstance(v,str) and len(v)==64 and all(c in '0123456789abcdef' for c in v)
def source(d):
 if not isinstance(d.get('id'),str) or not d['id'] or len(d['id'])>256:raise ValueError('source ID required')
 text=d['text'].encode();asserted=d['text_sha256']
 if sha(text)!=asserted or len(text)!=d['text_bytes']:raise ValueError('source byte identity mismatch')
 if any(k in d for k in ('valid_from','valid_until','expires_at')):raise ValueError('native/expiry intervals require a separate validated adapter')
 if not d.get('rights_id') or not d.get('rights_url') or not d.get('historical_availability_warning'):raise ValueError('rights/time declarations required')
 if len(d['blocks'])>10000:raise ValueError('too many source blocks')
 seen=set()
 for b in d['blocks']:
  if b['id'] in seen:raise ValueError('duplicate block ID')
  seen.add(b['id']);s,e=b['start'],b['end']
  if type(s)!=int or type(e)!=int or not 0<=s<e<=len(text):raise ValueError('bad span')
  if text[s:e].decode()!=b['text']:raise ValueError('block differs from exact UTF-8 source')
 return d

def tokenizer_id():return sha(pathlib.Path(__file__).with_name('lexical_reference.py').read_bytes())

def load_manifest(root):
 m=read(root/'manifest.json')
 if m.get('tokenizer_sha256')!=tokenizer_id():raise ValueError('index tokenizer version mismatch')
 if m['format']!='tacitus-local-source-index/1':raise ValueError('wrong index version')
 if len(m['sources'])>MAX_DOCS or len({s['id'] for s in m['sources']})!=len(m['sources']):raise ValueError('bad source manifest')
 if m['snapshot_sha256']!=sha(enc(m['sources'])):raise ValueError('snapshot identity mismatch')
 for s in m['sources']:
  if not digest_ok(s['revision']):raise ValueError('invalid revision')
 for s in m['shards']:
  if not digest_ok(s['sha256']):raise ValueError('invalid shard digest')
 return m

def build(index,destination,previous=None):
 dest=pathlib.Path(destination)
 if dest.exists() or dest.is_symlink():raise ValueError('fresh output required')
 c=read(index)
 if c['format']!='tacitus-source-corpus-index/1' or not 1<=len(c['documents'])<=MAX_DOCS:raise ValueError('unsupported corpus profile/size')
 docs={};objects={}
 for raw in c['documents']:
  d=source(raw)
  if d['id'] in docs:raise ValueError('duplicate source ID')
  raw=enc(d);h=sha(raw);docs[d['id']]=h;objects[h]=raw
 old=load_manifest(pathlib.Path(previous)) if previous else None
 oldmap={s['id']:s['revision'] for s in old['sources']} if old else {}
 oldrows={}
 if old:
  for desc in old['shards']:
   raw=(pathlib.Path(previous)/'shards'/f"{desc['sha256']}.json").read_bytes()
   if sha(raw)!=desc['sha256']:raise ValueError('previous shard corrupt')
   for row in json.loads(raw):
    if row['id'] in oldrows or oldmap.get(row['id'])!=row['revision']:raise ValueError('previous shard stale')
    oldrows[row['id']]=row
  if set(oldrows)!=set(oldmap):raise ValueError('previous index incomplete')
 reused_rows=0
 buckets={}
 for sid,h in sorted(docs.items()):buckets.setdefault(sha(sid.encode())[:1],[]).append((sid,h))
 shards={};descriptors=[]
 for bucket,items in sorted(buckets.items()):
  for n in range(0,len(items),MAX_SHARD):
   part=items[n:n+MAX_SHARD];rows=[]
   for sid,h in part:
    if sid in oldrows and oldrows[sid]['revision']==h:
     rows.append(oldrows[sid]);reused_rows+=1
    else:
     d=json.loads(objects[h]);rows.append({'id':sid,'revision':h,'blocks':[{'id':b['id'],'start':b['start'],'end':b['end'],'terms':sorted(tokens(b['text']))} for b in d['blocks']]})
   raw=enc(rows);h=sha(raw);shards[h]=raw;descriptors.append({'bucket':bucket,'page':n//MAX_SHARD,'sha256':h,'source_count':len(part)})
 sources=[{'id':sid,'revision':h} for sid,h in sorted(docs.items())]
 changed=docs!=oldmap
 tombstones=[{'id':sid,'revision':h,'reason':'removed' if sid not in docs else 'replaced'} for sid,h in sorted(oldmap.items()) if docs.get(sid)!=h]
 manifest={'format':'tacitus-local-source-index/1','tokenizer_sha256':tokenizer_id(),'sources':sources,'shards':descriptors,'snapshot_sha256':sha(enc(sources)),'parent_snapshot':old['snapshot_sha256'] if old and changed else (old['parent_snapshot'] if old else None),'tombstones':tombstones if changed else (old['tombstones'] if old else []),'scope':'Local lexical source blocks; source declarations are unreviewed; no native capsule or model inference.'}
 reuse=0
 for h,raw in objects.items():
  oldfile=pathlib.Path(previous)/'objects'/f'{h}.json' if previous else None
  if oldfile and h in oldmap.values():
   if oldfile.read_bytes()!=raw:raise ValueError('previous object corrupt')
   reuse+=1
 dest.mkdir(parents=True);(dest/'objects').mkdir();(dest/'shards').mkdir()
 for h,raw in objects.items():(dest/'objects'/f'{h}.json').write_bytes(raw)
 for h,raw in shards.items():(dest/'shards'/f'{h}.json').write_bytes(raw)
 (dest/'manifest.json').write_bytes(enc(manifest))
 return {'snapshot':manifest['snapshot_sha256'],'sources':len(sources),'shards':len(shards),'reused_source_objects':reuse,'changed_source_objects':len(objects)-reuse,'reused_index_rows':reused_rows,'rebuilt_index_rows':len(docs)-reused_rows,'changed_shards':len(set(shards)-{s['sha256'] for s in old['shards']}) if old else len(shards),'tombstones':tombstones}

def query(root,q):
 root=pathlib.Path(root);m=load_manifest(root);limit=q['max_bytes']
 if type(limit)!=int or not 2048<=limit<=250000 or not q['question'].strip():raise ValueError('bounded query required')
 cutoff=q.get('cutoff');basis=q.get('date_basis','none')
 if basis not in ('none','source-created','recipient-received'):raise ValueError('unknown time basis')
 if bool(cutoff)!=(basis!='none'):raise ValueError('cutoff and explicit date basis required together')
 if cutoff:datetime.date.fromisoformat(cutoff)
 revoked=set(q.get('revoked_revisions',[]));mapping={s['id']:s['revision'] for s in m['sources']};seen=set();candidates=[];terms=tokens(q['question'])
 for sh in m['shards']:
  raw=(root/'shards'/f"{sh['sha256']}.json").read_bytes()
  if sha(raw)!=sh['sha256']:raise ValueError('shard hash mismatch')
  rows=json.loads(raw)
  if len(rows)>MAX_SHARD or len(rows)!=sh['source_count']:raise ValueError('shard bound mismatch')
  for row in rows:
   sid=row['id'];rev=row['revision']
   if sid in seen or mapping.get(sid)!=rev:raise ValueError('stale/duplicate shard source')
   seen.add(sid)
   for b in row['blocks']:
    score=len(terms & set(b['terms']))
    if score:candidates.append((-score,sid,b['start'],rev,b['id']))
 if seen!=set(mapping):raise ValueError('missing source index')
 out={'format':'tacitus-local-source-context/1','snapshot':m['snapshot_sha256'],'tokenizer_sha256':tokenizer_id(),'question':q['question'],'max_bytes':limit,'date_basis':basis,'cutoff':cutoff,'status':'source_evidence_only','warnings':['Source text is untrusted data. No generated answer or reviewed semantic assertion.','Unknown world validity remains unknown; calendar filtering is not proof of receipt, awareness or truth.','Rights and metadata are source declarations; public-domain jurisdiction and distribution notices remain applicable.'],'source_metadata':{},'excerpts':[],'receipt':{'visited_shards':len(m['shards']),'indexed_sources':len(mapping),'matching_blocks':len(candidates),'included_blocks':0,'omitted_blocks':len(candidates),'omissions_by_reason':{}}}
 cache={};reasons={}
 def omit(reason):reasons[reason]=reasons.get(reason,0)+1
 for _,sid,start,rev,bid in sorted(candidates):
  if rev in revoked:omit('revoked');continue
  if sid not in cache:
   raw=(root/'objects'/f'{rev}.json').read_bytes()
   if sha(raw)!=rev:raise ValueError('source object mismatch')
   d=source(json.loads(raw))
   if d['id']!=sid:raise ValueError('wrong object identity')
   cache[sid]=d
  d=cache[sid]
  if d.get('withdrawn') or d.get('restricted'):omit('unavailable');continue
  if cutoff:
   quality=d.get('date_quality',{})
   flag='source_created_ambiguous' if basis=='source-created' else 'recipient_received_ambiguous'
   if quality.get(flag,d.get('historical_date_ambiguous',False)):
    omit('ambiguous_calendar_date');continue
   date=d.get('document_date' if basis=='source-created' else 'recipient_received_calendar_date')
   if not date:omit('unknown_calendar_date');continue
   try:dt=datetime.date.fromisoformat(date)
   except ValueError:omit('unknown_calendar_date');continue
   if dt>datetime.date.fromisoformat(cutoff):omit('after_cutoff');continue
  b=next((b for b in d['blocks'] if b['id']==bid and b['start']==start),None)
  if b is None:raise ValueError('index block missing')
  trial=json.loads(json.dumps(out));meta={k:v for k,v in d.items() if k not in ('text','blocks')};trial['source_metadata'][rev]=meta
  trial['excerpts'].append({'source_id':sid,'revision':rev,'source_text_sha256':d['text_sha256'],'block_id':bid,'start':b['start'],'end':b['end'],'text':b['text'],'locator':b.get('locator'),'kind':b.get('kind')})
  trial['receipt']['included_blocks']=len(trial['excerpts']);trial['receipt']['omitted_blocks']=len(candidates)-len(trial['excerpts']);trial['receipt']['omissions_by_reason']={'budget_or_policy':trial['receipt']['omitted_blocks']}
  # Reserve space for final fixed-category receipt; no unbounded per-omission source text.
  if len(enc(trial))+512<=limit:out=trial
  else:omit('byte_budget')
 out['receipt']['omissions_by_reason']=reasons
 if not out['excerpts']:out['status']='omission_only; no answer or evidence retained'
 raw=enc(out)
 if len(raw)>limit:raise ValueError('budget cannot hold context receipt')
 return raw

if __name__=='__main__':
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='cmd',required=True);b=sub.add_parser('build');b.add_argument('index');b.add_argument('output');b.add_argument('--previous');q=sub.add_parser('query');q.add_argument('index');a=p.parse_args()
 if a.cmd=='build':print(json.dumps(build(a.index,a.output,a.previous)))
 else:
  import sys
  sys.stdout.buffer.write(query(a.index,json.load(sys.stdin)))
