import copy,json,pathlib,tempfile,unittest,os
from collection import build,query,sha,enc,read,source
BASE=pathlib.Path(os.environ.get('TACITUS_CORPUS_INDEX','examples/july-1914/.data/corpus-index.json'))
class Tests(unittest.TestCase):
 def setUp(self):self.t=tempfile.TemporaryDirectory();self.r=pathlib.Path(self.t.name);self.c=read(BASE);self.p=self.r/'corpus.json';self.p.write_bytes(enc(self.c));self.store=self.r/'index';build(self.p,self.store)
 def tearDown(self):self.t.cleanup()
 def q(self,**kw):return {'question':'war peace mobilization','max_bytes':32768,**kw}
 def test_repeat_budget_multishard(self):
  a=query(self.store,self.q());self.assertEqual(a,query(self.store,self.q()));self.assertLessEqual(len(a),32768);d=json.loads(a);self.assertGreater(d['receipt']['visited_shards'],1);self.assertTrue(d['excerpts']);self.assertEqual(d['receipt']['omitted_blocks'],sum(d['receipt']['omissions_by_reason'].values()))
 def test_exact_quotes(self):
  d=json.loads(query(self.store,self.q()));orig={x['id']:x for x in self.c['documents']}
  for e in d['excerpts']:self.assertEqual(e['text'].encode(),orig[e['source_id']]['text'].encode()[e['start']:e['end']])
 def test_unchanged_incremental(self):
  r=build(self.p,self.r/'again',self.store);self.assertEqual(r['reused_source_objects'],166);self.assertEqual(r['changed_shards'],0);self.assertEqual((self.store/'manifest.json').read_bytes(),(self.r/'again/manifest.json').read_bytes())
 def test_metadata_revision_and_deletion(self):
  c=copy.deepcopy(self.c);removed=c['documents'].pop();c['documents'][0]['title']+=' revised';self.p.write_bytes(enc(c));r=build(self.p,self.r/'new',self.store);self.assertEqual(r['changed_source_objects'],1);self.assertEqual(len(r['tombstones']),2);self.assertTrue((self.store/'manifest.json').exists());m=read(self.r/'new/manifest.json');self.assertNotIn(removed['id'],[x['id'] for x in m['sources']])
 def test_bad_source_duplicate_utf8(self):
  c=copy.deepcopy(self.c);c['documents'].append(c['documents'][0]);self.p.write_bytes(enc(c));self.assertRaises(ValueError,build,self.p,self.r/'bad')
  d=copy.deepcopy(self.c['documents'][0]);d['blocks'][0]['start']=1;self.assertRaises((ValueError,UnicodeDecodeError),source,d)
 def test_corrupt_shard(self):
  m=read(self.store/'manifest.json');p=self.store/'shards'/f"{m['shards'][0]['sha256']}.json";p.write_text('[]');self.assertRaises(ValueError,query,self.store,self.q())
 def test_missing_selected_object(self):
  d=json.loads(query(self.store,self.q()));rev=d['excerpts'][0]['revision'];(self.store/'objects'/f'{rev}.json').unlink();self.assertRaises(FileNotFoundError,query,self.store,self.q())
 def test_revocation_no_source_metadata(self):
  d=json.loads(query(self.store,self.q()));rev=d['excerpts'][0]['revision'];o=json.loads(query(self.store,self.q(revoked_revisions=[rev])));self.assertNotIn(rev,o['source_metadata']);self.assertTrue(all(e['revision']!=rev for e in o['excerpts']))
 def test_unknown_dates_do_not_pass(self):
  o=json.loads(query(self.store,self.q(cutoff='1914-07-27',date_basis='recipient-received')))
  for d in o['source_metadata'].values():self.assertTrue(d['recipient_received_calendar_date']);self.assertLessEqual(d['recipient_received_calendar_date'],'1914-07-27')
 def test_fresh_destination(self):
  self.assertRaises(ValueError,build,self.p,self.store);link=self.r/'link';link.symlink_to(self.r/'missing');self.assertRaises(ValueError,build,self.p,link);self.assertFalse((self.r/'missing').exists())
 def test_shard_bound(self):
  m=read(self.store/'manifest.json');self.assertTrue(all(s['source_count']<=25 for s in m['shards']))
 def test_collision_overflow_and_small_budget(self):
  c=copy.deepcopy(self.c);docs=[];i=0
  while len(docs)<26:
   sid=f'collision-{i}';i+=1
   if sha(sid.encode())[:2]!='00':continue
   d=copy.deepcopy(c['documents'][0]);d['id']=sid;docs.append(d)
  c['documents']=docs;self.p.write_bytes(enc(c));build(self.p,self.r/'collision');m=read(self.r/'collision/manifest.json');self.assertEqual([x['source_count'] for x in m['shards']],[25,1]);o=json.loads(query(self.r/'collision',self.q(max_bytes=2048)));self.assertEqual(o['excerpts'],[])
 def test_snapshot_tamper(self):
  m=read(self.store/'manifest.json');m['snapshot_sha256']='0'*64;(self.store/'manifest.json').write_bytes(enc(m));self.assertRaises(ValueError,query,self.store,self.q())
 def test_expiry_profile_not_silently_accepted(self):
  d=copy.deepcopy(self.c['documents'][0]);d['valid_until']=1;self.assertRaises(ValueError,source,d)
 def test_basis_specific_ambiguity(self):
  c=copy.deepcopy(self.c);c['documents']=c['documents'][:1];d=c['documents'][0];d['document_date']='1914-07-26';d['recipient_received_calendar_date']='1914-07-27';d['historical_date_ambiguous']=True;d['date_quality']={'source_created_ambiguous':True,'recipient_received_ambiguous':False};self.p.write_bytes(enc(c));build(self.p,self.r/'dates')
  a=json.loads(query(self.r/'dates',self.q(question='Russian',cutoff='1914-07-30',date_basis='source-created')));b=json.loads(query(self.r/'dates',self.q(question='Russian',cutoff='1914-07-30',date_basis='recipient-received')));self.assertFalse(a['excerpts']);self.assertTrue(b['excerpts'])
 def test_tokenizer_version_mismatch(self):
  m=read(self.store/'manifest.json');m['tokenizer_sha256']='0'*64;(self.store/'manifest.json').write_bytes(enc(m));self.assertRaises(ValueError,query,self.store,self.q());self.assertRaises(ValueError,build,self.p,self.r/'new',self.store)
 def test_invalid_budget(self):self.assertRaises(ValueError,query,self.store,self.q(max_bytes=100))
if __name__=='__main__':unittest.main()
