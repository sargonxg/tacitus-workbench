# Local collection-wide lexical source selection

This bounded adapter indexes the existing `tacitus-source-corpus-index/1` catalog. It searches source blocks across all shards and returns exact source excerpts with full declared provenance, rights and historical-clock metadata under one serialized byte cap. It does not invent claims, generate answers, create a native capsule, authenticate users or infer semantic relations.

Native source/assertion limits remain unchanged. Index shards contain at most 25 sources; they are storage/index partitions, not native capsules. A future source-selection-to-native-authoring step must still supply explicit validated annotations and respect the native 32-source limit.

## Commands

```sh
python3 collection.py build /path/to/corpus-index.json /new/index-directory
python3 collection.py build /path/to/revised/corpus-index.json /new/revision-directory --previous /old/index-directory
printf '%s' '{"question":"mediation peace","max_bytes":32768}' | python3 collection.py query /index-directory
TACITUS_CORPUS_INDEX=/path/to/original-166/corpus-index.json python3 -m unittest -v test_collection.py
```

An optional calendar filter requires both `cutoff` (ISO date) and `date_basis` (`source-created` or `recipient-received`). Unknown dates and basis-specific ambiguous dates are excluded, including composite records with later embedded dispatches when flagged by the source audit. Filtering a later published edition does not prove historical awareness, dispatch delivery, world validity or truth. Native validity/expiry interval fields are explicitly unsupported and rejected rather than interpreted as calendar dates. Caller-supplied `revoked_revisions` suppresses matching source metadata and excerpts. Current revocations must come from the caller; there is no remote authorization/revocation service.

Every source revision hashes the full parsed source object, including exact text bytes and all metadata. This is deterministic Python JSON encoding, not RFC8785/JCS or a cross-language canonicalization promise. Changed rights or dates change the revision even if text is unchanged. A current manifest excludes deleted/replaced revisions and records tombstones; previous directories remain intact. Identical updates reuse validated index rows without retokenizing. Source object bytes are verified and copied into the new directory; this is logical reuse, not disk-level deduplication. The snapshot digest binds source inventory; tokenizer and shard identities are checked separately, without an authenticated-manifest claim. Hash-bucket overflow is divided deterministically into pages of at most 25 sources, so an insertion can change more than one shard.

The query verifies shard hashes, complete manifest coverage and selected source object hashes before producing output. All candidate shards are searched. One global budget includes source metadata, excerpt text, warnings and receipt. A small conservative receipt reserve may leave unused bytes. The receipt reports aggregate omission reasons, not an exhaustive per-item omission ledger. No-match or too-small-for-evidence output is explicitly omission-only; a budget too small even for the receipt is rejected.

This is a local-owner prototype for the known research corpus profile, not a validator for arbitrary marketplace uploads. Hashes detect inconsistency, not authenticity; a hostile caller can invent a new manifest. No general ACL, privacy filter or semantic correction-closure guarantee is provided for raw source-block selection. Source text must remain escaped/untrusted in any consumer. Native graph-aware reuse is a separate reviewed path.

`lexical_reference.py` is copied unchanged from the Apache-2.0 TACITUS core's existing evaluation harness (`scripts/capsule-retrieval-evaluation/compare.py`, public revision 0d47eafd93f2b4a5e4a926d3c761410b1c319cd6); only its `tokens` helper is reused here. Preserve its Apache-2.0 dependency notices when integrating. New original adapter code has not been publicly published or assigned final commercial terms here.

## Verified local result

Independent review reproduced 17 regressions and the 622-record run against catalog SHA-256 `75e17341a7c78203ea31526863fdd3ec2b0a2ed272b9c6b9e4f6f900312c993c`. All five illustrative queries visited all 32 shards and respected their 32,768-byte cap. An unchanged update reused 622 index rows; an explicit metadata-only regression rebuilt one row and one shard. The initial 166-to-622 expansion reused only four memoir rows because all existing FRUS records received new date-quality metadata. These counts are not semantic-quality or speed gains.

The source catalog remains subject to its separate historical/content review. The local report is `results/report.json`; payloads and exact requests are alongside it.
