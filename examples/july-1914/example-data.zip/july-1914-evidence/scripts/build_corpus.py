#!/usr/bin/env python3
"""Deterministic structural extraction of pinned public source bytes; no semantic extractor."""
from pathlib import Path
import xml.etree.ElementTree as ET
import hashlib,json,re,datetime,collections
ROOT=Path(__file__).resolve().parents[1]
NS='http://www.tei-c.org/ns/1.0'; XID='{http://www.w3.org/XML/1998/namespace}id'
T=lambda n:'{'+NS+'}'+n
sha=lambda b:hashlib.sha256(b).hexdigest()
norm=lambda s:re.sub(r'\s+',' ',s).strip()
PIN='6170e4b32c1224002db2fe0c5d8d910597cddc2e'
CREATED='2026-10-18T12:50:08Z'
URL='https://history.state.gov/historicaldocuments/frus1914Supp/'
raw=(ROOT/'upstream/frus1914Supp.xml').read_bytes(); root=ET.fromstring(raw)
rawhash=sha(raw)
# Notes and page markers are editorial layers; never silently insert them into historical text.
def inline(e):
 out=e.text or ''
 for c in e:
  tag=c.tag.rsplit('}',1)[-1]
  if tag in ('note','pb'): pass
  elif tag=='lb': out+=' '
  else: out+=inline(c)
  out+=c.tail or ''
 return out
def historical_elements(e):
 if e.tag in (T('note'),T('pb')): return
 yield e
 for c in e: yield from historical_elements(c)
people={e.get(XID):norm(inline(e)) for e in root.iter(T('persName')) if e.get(XID)}
blocks_tags={'head','dateline','p','signed','opener','salute','trailer'}
# An outer p may contain a list; preserve it as one structural paragraph, not inflated counts.
def blocks(e,path=''):
 tag=e.tag.rsplit('}',1)[-1]
 if tag in ('note','pb'):return
 if tag in blocks_tags:
  v=norm(inline(e))
  if v: yield (tag,v,path,e)
 else:
  counters=collections.Counter()
  for c in e:
   n=c.tag.rsplit('}',1)[-1]; counters[n]+=1
   yield from blocks(c,path+f'/{n}[{counters[n]}]')
def build_text(blocklist,docid):
 parts=[]; spans=[]; pos=0
 for i,(tag,text,loc,_) in enumerate(blocklist):
  if parts:pos+=2
  b=text.encode();spans.append({'id':f'{docid}:b{i+1:04}','kind':tag,'start':pos,'end':pos+len(b),'text':text,'locator':loc})
  parts.append(text);pos+=len(b)
 return '\n\n'.join(parts)+'\n',spans
months={name:f'{i:02}' for i,name in enumerate(['January','February','March','April','May','June','July','August','September','October','November','December'],1)}
records=[]
for n in range(24,186):
 eid=f'd{n}';docid=f'frus1914Supp-{eid}'
 d=next(e for e in root.iter(T('div')) if e.get(XID)==eid)
 bs=list(blocks(d,f"TEI div[@xml:id='{eid}']"));text,spans=build_text(bs,docid)
 (ROOT/'texts'/f'{docid}.txt').write_text(text,encoding='utf-8',newline='\n')
 dl=d.find(T('dateline')); date_element=dl.find('.//'+T('date')) if dl is not None else None
 date_encoded=date_element.get('when') if date_element is not None else None
 date_text=norm(inline(date_element)) if date_element is not None else None
 dateline=norm(inline(dl)) if dl is not None else ''
 rec_match=re.search(r'\[Received ([^\]]+)',dateline)
 received_raw=rec_match.group(1).strip() if rec_match else None
 explicit=None
 if received_raw:
  m=re.search(r'('+'|'.join(months)+r') (\d{1,2})(?:, (1914))?',received_raw)
  if m: explicit=f'1914-{months[m[1]]}-{int(m[2]):02}'
 doc_date=date_encoded[:10] if date_encoded and re.match(r'1914-\d\d-\d\d',date_encoded) else None
 marked=[]
 for e in (x for x in historical_elements(d) if x.tag==T('persName')):
  ref=e.get('corresp');label=norm(inline(e))
  if ref and label:
   marked.append({'entity_id':'frus-person:'+ref.lstrip('#'),'source_authority_id':ref,'label':people.get(ref.lstrip('#'),label),'surface':label,'role':e.get('type'),'annotation_origin':'publisher TEI persName markup; not assistant inference'})
 unique={json.dumps(e,sort_keys=True):e for e in marked}
 notes=[{'kind':e.get('type','editorial_note'),'id':e.get(XID),'text':norm(''.join(e.itertext()))} for e in d.iter(T('note'))]
 dates=[{'text':norm(inline(e)),'attributes':dict(e.attrib)} for e in d.iter(T('date'))]
 source_note=next((x['text'] for x in notes if x['kind']=='source'),None)
 title=norm(inline(d.find(T('head'))))
 record={'id':docid,'source_kind':'contemporaneous_dispatch_in_later_edition','url':URL+eid,'title':title,'edition':'FRUS 1914 Supplement, The World War (Government Printing Office, 1928), official TEI transcription','edition_publication_year':1928,'language':'en','language_note':'English edition; [Translation] is preserved when present. The original foreign language is not inferred.','translation_marker_present':'[Translation]' in text,'text_path':f'texts/{docid}.txt','text':text,'text_sha256':sha(text.encode()),'text_bytes':len(text.encode()),'upstream_path':'upstream/frus1914Supp.xml','upstream_sha256':rawhash,'upstream_commit':PIN,'upstream_url':f'https://raw.githubusercontent.com/HistoryAtState/frus/{PIN}/volumes/frus1914Supp.xml','upstream_locator':f"TEI div[@xml:id='{eid}']",'archival_file_reference':source_note,'document_date':doc_date,'document_date_raw':date_text,'source_encoded_date':date_encoded,'dateline_raw':dateline,'received_raw':received_raw,'recipient_received_calendar_date':explicit,'recipient_receipt_precision':'calendar date; 1914 contextual year' if explicit else ('time only; date not asserted' if received_raw else 'unknown'),'historical_availability_warning':'Document date establishes the dated source record, not that any particular diplomat had received/read it. Receipt dates are separate. FRUS public edition appeared in 1928; current corpus ingestion is 2026.','dates_in_source':dates,'source_marked_entities':list(unique.values()),'editorial_notes':notes,'blocks':spans,'rights_id':'frus-public-domain','rights_url':f'https://github.com/HistoryAtState/frus/blob/{PIN}/README.md#license','annotation_status':'Structural extraction from publisher TEI; semantic claims are separate unreviewed assistant annotations.'}
 records.append(record)
# Four meaningful original sections, not duplicate documents or synthetic scaling.
mraw=(ROOT/'upstream/lichnowsky-39457.txt').read_bytes();mt=mraw.decode('utf-8').replace('\r\n','\n')
sections=[('serbian-crisis','THE SERBIAN CRISIS','THE ENGLISH DECLARATION OF WAR','31–37'),('english-declaration','THE ENGLISH DECLARATION OF WAR','RETROSPECT','37–38'),('retrospect','RETROSPECT','MY RETURN','38–40'),('responsibility','THE QUESTION OF RESPONSIBILITY','THE ENEMY POINT OF VIEW','40–41')]
for suffix,start,end,pages in sections:
 begin=mt.index('\n'+start+'\n',mt.index('MY MISSION TO LONDON\n'))+1
 finish=mt.index('\n'+end+'\n',begin)
 section=mt[begin:finish].strip(); bs=[('head' if i==0 else 'p',norm(p),f'Section {start}; paragraph {i}',None) for i,p in enumerate(re.split(r'\n\s*\n',section)) if norm(p)]
 docid='lichnowsky-'+suffix;text,spans=build_text(bs,docid)
 (ROOT/'texts'/f'{docid}.txt').write_text(text,encoding='utf-8',newline='\n')
 records.append({'id':docid,'source_kind':'retrospective_memoir_section','url':'https://www.gutenberg.org/ebooks/39457','title':'My Mission to London, 1912–1914: '+start.title(),'edition':'New York: George H. Doran Company; English translation with preface by Gilbert Murray, as transcribed in Project Gutenberg ebook 39457','edition_publication_year':None,'edition_year_note':'1918 catalog attribution not independently confirmed in this text; title page is undated. No exact publication timestamp asserted.','language':'en','language_note':'Historical English translation; translator unnamed in this edition. Quoted French strings remain within English source. No new translation supplied.','translation_marker_present':False,'text_path':f'texts/{docid}.txt','text':text,'text_sha256':sha(text.encode()),'text_bytes':len(text.encode()),'upstream_path':'upstream/lichnowsky-39457.txt','upstream_sha256':sha(mraw),'upstream_commit':None,'upstream_url':'https://www.gutenberg.org/ebooks/39457.txt.utf-8','upstream_locator':f'Section {start}; printed pages {pages}; LF-normalized source character range {begin}:{finish}','document_date':None,'document_date_raw':'Written August 1916, according to the edition’s Biographical Note','source_encoded_date':None,'dateline_raw':None,'received_raw':None,'recipient_received_calendar_date':None,'recipient_receipt_precision':'not applicable','composition_period':'1916-08','historical_availability_warning':'Retrospective testimony composed after the events; excluded from every 1914 as-of view, even where it narrates July 1914 events.','dates_in_source':[],'source_marked_entities':[],'editorial_notes':[],'blocks':spans,'rights_id':'gutenberg-39457-pd-us','rights_url':'https://www.gutenberg.org/ebooks/39457','annotation_status':'Structural section extraction; semantic claims are separate unreviewed assistant annotations.'})
full={'format':'tacitus-source-corpus-index/1','title':'Could a diplomat see escalation coming in July 1914?','created_at':CREATED,'scope':'162 distinct FRUS documents d24–d185 covering the crisis and early war, plus 4 explicitly retrospective Lichnowsky sections. Not 166 books or independently annotated claims.','native_contract':'Existing tacitus SourceRecord/Capture/Graph is used for bounded annotated capsules. This index is a reproducible corpus catalog, not a replacement semantic schema.','document_count':len(records),'frus_documents':162,'memoir_sections':4,'text_bytes':sum(x['text_bytes'] for x in records),'structural_blocks':sum(len(x['blocks']) for x in records),'paragraph_blocks':sum(sum(b['kind']=='p' for b in x['blocks']) for x in records),'transform':'UTF-8 text. FRUS: remove TEI inline note/pb elements, normalize whitespace within each outer block, preserve text spelling/punctuation, join blocks with two LF and one final LF. Notes retained separately, never treated as contemporaneous telegram text. Memoir: normalize CRLF to LF, select named sections, normalize whitespace within existing blank-line paragraphs. No OCR correction, no semantic extraction.','documents':records}
(ROOT/'corpus-index.json').write_text(json.dumps(full,ensure_ascii=False,indent=2)+'\n')
manifest={k:v for k,v in full.items() if k!='documents'}
manifest['documents']=[{k:v for k,v in d.items() if k not in ('text','blocks','source_marked_entities','editorial_notes','dates_in_source')} for d in records]
manifest['upstream_downloads']=json.loads((ROOT/'upstream/downloads.json').read_text())
(ROOT/'corpus-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k not in ('documents','upstream_downloads')},indent=2))
