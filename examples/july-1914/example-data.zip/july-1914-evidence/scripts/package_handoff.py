#!/usr/bin/env python3
"""Package only reviewed-scope source/provenance/example files into a reproducible local archive; never upload."""
from pathlib import Path
import json,hashlib,zipfile,argparse
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();out=a.output.resolve()
if out.exists():raise SystemExit('Refusing to replace an existing handoff archive')
exclude={'upstream/lichnowsky-catalog.html','RELEASE_FILES.json'}
files=sorted(x for x in R.rglob('*') if x.is_file() and '__pycache__' not in x.parts and x.relative_to(R).as_posix() not in exclude and x.resolve()!=out)
entries=[{'path':x.relative_to(R).as_posix(),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in files]
inv={'format':'tacitus-example-inventory/1','publication_status':'example source distribution; no external upload performed by this script','native_candidate_source_pin':'03fe8e6','historical_annotations':'assistant-authored, unreviewed','excluded':['contemporary Gutenberg catalog HTML','Python caches','external credentials or user-private material'],'files':entries}
(R/'RELEASE_FILES.json').write_text(json.dumps(inv,indent=2)+'\n')
files.append(R/'RELEASE_FILES.json')
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:
  i=zipfile.ZipInfo('july-1914-evidence/'+f.relative_to(R).as_posix(),date_time=(2026,10,18,13,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o644<<16;z.writestr(i,f.read_bytes())
print(json.dumps({'path':str(out),'files':len(files),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
