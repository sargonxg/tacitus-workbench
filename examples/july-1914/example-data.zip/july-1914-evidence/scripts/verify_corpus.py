#!/usr/bin/env python3
"""Offline structural/temporal integrity tests. Passing does NOT score semantic quality."""
from pathlib import Path
import hashlib,json,unittest,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from historical_snapshot import select
C=json.loads((ROOT/'corpus-index.json').read_text());D={d['id']:d for d in C['documents']};CAP=json.loads((ROOT/'annotations/capture.unfingerprinted.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
class CorpusIntegrity(unittest.TestCase):
 def test_unique_real_document_ids(self):
  self.assertEqual(len(D),166); self.assertEqual(sum(d['source_kind']=='contemporaneous_dispatch_in_later_edition' for d in D.values()),162)
  self.assertEqual({f'frus1914Supp-d{i}' for i in range(24,186)},{x for x in D if x.startswith('frus')})
 def test_upstream_bytes(self):
  for r in json.loads((ROOT/'upstream/downloads.json').read_text()):
   p=ROOT/r['path']
   if p.name=='lichnowsky-catalog.html' and not p.exists():continue # excluded from no-charge release whitelist
   b=p.read_bytes();self.assertEqual(len(b),r['bytes']);self.assertEqual(sha(b),r['sha256'])
 def test_all_texts_hash_and_exact_blocks(self):
  for d in D.values():
   b=(ROOT/d['text_path']).read_bytes();self.assertEqual(sha(b),d['text_sha256']);self.assertEqual(len(b),d['text_bytes']);self.assertEqual(b.decode(),d['text'])
   self.assertEqual('\n\n'.join(x['text'] for x in d['blocks'])+'\n',d['text'])
   for s in d['blocks']:self.assertEqual(b[s['start']:s['end']].decode(),s['text'])
 def test_native_schema_limits_and_exact_evidence(self):
  self.assertLessEqual(len(CAP['documents']),32);self.assertLessEqual(len(CAP['assertions']),256)
  sources={s['id']+'@1':s for s in CAP['documents']}
  for s in sources.values():
   self.assertEqual(s['text'],D[s['id']]['text']);self.assertEqual(s['original_hash'],sha(s['text'].encode()));self.assertEqual(s['original_hash'],s['text_hash']);self.assertIsNone(s['published_at']);self.assertGreater(s['available_at'],1700000000)
  for a in CAP['assertions']:
   self.assertTrue(a['evidence'])
   for e in a['evidence']:
    s=sources[e['source']];self.assertEqual(e['text_hash'],s['text_hash']);self.assertEqual(e['original_language'],s['language']);self.assertTrue(s['text'].encode()[e['start']:e['end']].decode())
 def test_all_literal_phrase_spans(self):
  records=json.loads((ROOT/'annotations/phrase-occurrences.json').read_text())['occurrences'];self.assertEqual(len(records),160)
  for p in records:self.assertEqual(D[p['source_id']]['text'].encode()[p['start']:p['end']].decode(),p['matched_text'])
 def test_created_by_july27_has_no_hindsight(self):
  s=select(C,CAP,'1914-07-27','source-created');self.assertIn('gerard-july27-optimism',s['claim_ids']);self.assertNotIn('gerard-july30-pessimism',s['claim_ids']);self.assertNotIn('gerard-outlook-shift',s['claim_ids']);self.assertFalse(any(x.startswith('lichnowsky') for x in s['source_ids']))
 def test_delayed_receipt_does_not_leak(self):
  self.assertEqual(D['frus1914Supp-d28']['document_date'],'1914-07-13');self.assertEqual(D['frus1914Supp-d28']['recipient_received_calendar_date'],'1914-07-27')
  s=select(C,CAP,'1914-07-26','recipient-received');self.assertNotIn('frus1914Supp-d28',s['source_ids'])
 def test_undated_and_cross_date_distinctions(self):
  s=select(C,CAP,'1914-07-30','source-created');r=select(C,CAP,'1914-07-30','recipient-received')
  self.assertNotIn('frus1914Supp-d39',s['source_ids']);self.assertIn('frus1914Supp-d39',r['source_ids']);self.assertIsNone(D['frus1914Supp-d39']['document_date'])
  self.assertNotIn('frus1914Supp-d40',s['source_ids']);self.assertIn('frus1914Supp-d40',r['source_ids'])
 def test_unknown_receipt_day_is_withheld(self):
  d=D['frus1914Supp-d27'];self.assertIsNone(d['recipient_received_calendar_date']);self.assertIn('Received',d['dateline_raw']);self.assertNotIn(d['id'],select(C,CAP,'1914-07-31','recipient-received')['source_ids'])
 def test_changed_outlook_is_not_timeless_contradiction(self):
  links=CAP['graph']['links'];pair={'gerard-july27-optimism','gerard-july30-pessimism'}
  self.assertFalse(any({e['from'],e['to']}==pair and e['kind']=='contradicts' for e in links));self.assertIn('gerard-outlook-shift',select(C,CAP,'1914-07-30','source-created')['claim_ids'])
 def test_reported_event_date_does_not_enable_memoir(self):
  h=json.loads((ROOT/'annotations/historical-view.json').read_text());m=next(x for x in h['claims'] if x['claim_id']=='lichnowsky-july31-declaration-date');self.assertEqual(m['event_date'],'1914-07-31');self.assertFalse(m['historical_1914_eligible']);self.assertNotIn(m['claim_id'],select(C,CAP,'1914-12-31','source-created')['claim_ids'])
 def test_native_fingerprinting_does_not_change_content(self):
  path=ROOT/'annotations/capture.json'
  if not path.exists():self.skipTest('native fingerprinted capture not supplied')
  a=json.loads(path.read_text());b=json.loads(json.dumps(CAP));fingerprints=a['graph'].pop('claim_fingerprints');b['graph'].pop('claim_fingerprints');self.assertEqual(len(fingerprints),len(b['assertions']))
  for obj in (a,b):
   for node in obj['graph']['nodes'].values():node['claims']=sorted(node['claims'])
  self.assertEqual(a,b)
 def test_native_payload_does_not_assert_review(self):
  self.assertFalse(any(k in CAP for k in ('reviews','canonical','accepted')));self.assertTrue(all(x is None for x in CAP['observed_at'].values()));self.assertEqual(CAP['graph']['knowledge'],{})
if __name__=='__main__':unittest.main(verbosity=2)
