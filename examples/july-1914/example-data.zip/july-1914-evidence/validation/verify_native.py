import json,pathlib,hashlib,subprocess,tempfile,zipfile,argparse,datetime,sys
R=pathlib.Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description='Verify against the existing native knowledge_capture binary')
parser.add_argument('--binary',required=True,type=pathlib.Path)
B=parser.parse_args().binary.resolve()
if not B.is_file(): parser.error('native binary does not exist')
c=json.loads((R/'annotations/capture.json').read_text());docs={f"{x['id']}@{x['version']}":x for x in c['documents']}; claims={x['id']:x for x in c['assertions']};checks=[]
def run(args,req=None):return subprocess.run([str(B),*map(str,args)],input=None if req is None else json.dumps(req).encode(),capture_output=True)
for p in sorted((R/'validation/native').glob('*.request.json')):
 req=json.loads(p.read_text());out=p.with_name(p.name.replace('.request','.context')).read_bytes();again=run(['reuse',R/'july-1914.native-v2.zip'],req);assert again.returncode==0 and again.stdout==out
 d=json.loads(out);assert len(out)<=req['max_bytes']
 for key,x in d['context']['claims'].items():
  assert x['assertion']==claims[key]
  for cit in x['citations']:
   s=cit['span'];src=docs[s['source']];assert src['text'].encode()[s['start']:s['end']].decode()==cit['text'];assert hashlib.sha256(src['text'].encode()).hexdigest()==s['text_hash']
 checks.append({'case':p.stem,'exact_reproduction':True,'claims':len(d['context']['claims']),'bytes':len(out)})
req=json.loads((R/'validation/native/mobilization.request.json').read_text())
for name,delta in [('strict',{'time_mode':'require_declared_interval'}),('pre_ingestion',{'known_as_of':c['manifest']['created_at']-1}),('historical_1914',{'known_as_of':int(datetime.datetime(1914,7,27,tzinfo=datetime.timezone.utc).timestamp())}),('revoked',{'revoked_sources':[next(iter(docs))]})]:
 x=run(['reuse',R/'july-1914.native-v2.zip'],req|delta);assert x.returncode!=0 and not x.stdout;checks.append({'case':name,'rejected_empty_stdout':True})
with tempfile.TemporaryDirectory() as t:
 new=pathlib.Path(t)/'roundtrip.zip';x=run(['pack',R/'annotations/capture.json',new]);assert x.returncode==0;assert new.read_bytes()==(R/'july-1914.native-v2.zip').read_bytes();checks.append({'case':'deterministic_repack','exact_bytes':True})
 bad=pathlib.Path(t)/'tampered.zip'
 with zipfile.ZipFile(new) as src,zipfile.ZipFile(bad,'w') as dst:
  changed=False
  for n in src.namelist():
   b=src.read(n)
   if n.startswith('evidence/') and not changed:b+=b'!';changed=True
   dst.writestr(n,b)
 x=run(['inspect',bad]);assert x.returncode!=0 and not x.stdout;checks.append({'case':'evidence_tamper','rejected_empty_stdout':True})
receipt={'archive_sha256':hashlib.sha256((R/'july-1914.native-v2.zip').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'checks':checks,'scope':'Structural local validation only; annotations unreviewed; modern ingestion checkpoint is not historical knowledge.'}
(R/'validation/native/acceptance.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
